﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace EFDemo
{
    public partial class FormEFDemo : Form
    {
        public FormEFDemo()
        {
            InitializeComponent();
        }

        private void btnSelect_Click(object sender, EventArgs e)
        {
            // select
            DemoEntities de = new DemoEntities();
            var q = de.User.Where(r => r.Country == "China");
            textBox1.Text = "";
            foreach (User u in q)
            {
                textBox1.Text += string.Format("{0},{1},{2},{3}", u.Name, u.Password, u.Country, u.Email + Environment.NewLine);
            }
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            // update
            DemoEntities de = new DemoEntities();
            var q = de.User.Where(r => r.Name == "Clark");
            foreach (User u in q)
            {
                u.Email = textBox2.Text;
            }
            de.SaveChanges();
        }

        private void btnInsert_Click(object sender, EventArgs e)
        {
            // insert
            try
            {
                DemoEntities de = new DemoEntities();
                var r = de.User.CreateObject();
                r.Name = textBox3.Text.Split(',')[0];
                r.Password = textBox3.Text.Split(',')[1];
                r.Country = textBox3.Text.Split(',')[2];
                r.Email = textBox3.Text.Split(',')[3];
                de.User.AddObject(r);
                de.SaveChanges();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.InnerException.Message);
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            // delete
            try
            {
                DemoEntities de = new DemoEntities();
                var q = de.User.Where(r => r.Name == textBox4.Text);
                de.User.DeleteObject(q.First());
                de.SaveChanges();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
